# A6 Submission Artifacts — Expiry-Aware Food Inventory Prioritization Engine

This archive contains the academic presentation, project report, viva notes, practical application addendum, VGU rubric reference, and supporting images from the C11 project package.

## Contents
- Project report: PDF and editable DOCX
- Project presentation: PDF and editable PPTX
- Viva notes: PDF and editable DOCX
- Practical inventory app addendum: PDF and editable DOCX
- VGU A6 rubric reference PDF
- Benchmark and architecture figures: selection timing, policy simulation, expired quantity, operation counts, and system architecture

The runnable C11 source, tests, methodology, and CSV datasets are stored separately in the repository. The benchmark graphs illustrate the committed synthetic results; they are not claims about real-world food-waste reduction or proof of food safety.
